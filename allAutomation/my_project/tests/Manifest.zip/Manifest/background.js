chrome.runtime.onInstalled.addListener(() => {
  console.log("Microphone Simulation Extension Installed");
});
