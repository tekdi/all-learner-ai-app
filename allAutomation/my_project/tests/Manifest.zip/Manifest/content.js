function simulateMicrophoneInput(audioFilePath) {
  const context = new AudioContext();
  fetch(audioFilePath)
    .then(response => response.arrayBuffer())
    .then(arrayBuffer => context.decodeAudioData(arrayBuffer))
    .then(audioBuffer => {
      const source = context.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(context.destination);
      source.start();
    })
    .catch(console.error);
}

// Path to the audio file (can be adjusted as needed)
const audioFilePath = chrome.runtime.getURL("output_audio.wav");
simulateMicrophoneInput(audioFilePath);
