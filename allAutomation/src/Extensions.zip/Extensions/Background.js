chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action == "playAudio") {
        var audio = new Audio(request.url);
        audio.play();
    }
});